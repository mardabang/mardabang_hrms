package com.mardabang.hrms.attendance.service;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mardabang.hrms.attendance.dto.AttendanceManualRequest;
import com.mardabang.hrms.attendance.dto.AttendancePunchRequest;
import com.mardabang.hrms.attendance.dto.ShiftDto;
import com.mardabang.hrms.attendance.entity.AttendanceRecord;
import com.mardabang.hrms.attendance.entity.AttendanceStatus;
import com.mardabang.hrms.attendance.entity.ShiftType;
import com.mardabang.hrms.attendance.repository.AttendanceRepository;
@Service
@Transactional
public class AttendanceService {

    private final AttendanceRepository attendanceRepository;
    

    /*
     * Company location
     */
    private static final double COMPANY_LATITUDE = 16.720236;
    private static final double COMPANY_LONGITUDE = 74.460701;

    /*
     * Allowed attendance radius
     */
    private static final double ALLOWED_RADIUS_METERS = 150.0;

    /*
     * Late threshold
     *
     * Currently using 09:00 AM because the existing system
     * does not have a separate shift-start-time field.
     */
    private static final LocalTime GENERAL_SHIFT_START = LocalTime.of(9, 0);

    public AttendanceService(AttendanceRepository attendanceRepository) {
        this.attendanceRepository = attendanceRepository;
    }

    // =========================================================
    // CHECK IN
    // =========================================================

    public AttendanceRecord checkIn(AttendancePunchRequest request) {

        LocalDate today = LocalDate.now();
        LocalTime currentTime = LocalTime.now();

        validateLocation(
                request.getLatitude(),
                request.getLongitude()
        );

        /*
         * Prevent duplicate check-in for the same employee today.
         */
        if (attendanceRepository
                .findByEmployeeCodeAndAttendanceDate(
                        request.getEmployeeCode(),
                        today)
                .isPresent()) {

            throw new IllegalStateException(
                    "Attendance already marked for employee "
                            + request.getEmployeeCode()
                            + " today."
            );
        }

        AttendanceRecord record = new AttendanceRecord();
        
        record.setFirmCode(request.getFirmCode());
        record.setEmployeeCode(request.getEmployeeCode());
        record.setEmployeeName(request.getEmployeeName());
        record.setDepartment(request.getDepartment());
        record.setTeam(request.getTeam());
        record.setShift(request.getShift());
        record.setAttendanceDate(today);
        record.setCheckInTime(currentTime);
        record.setRecordedBy(request.getRecordedBy());

        record.setCheckInLatitude(request.getLatitude());
        record.setCheckInLongitude(request.getLongitude());

        record.setOvertime(0.0);

        record.setStatus(
                determineStatus(currentTime)
        );

        return attendanceRepository.save(record);
    }

    // =========================================================
    // CHECK OUT
    // =========================================================

    public AttendanceRecord checkOut(String employeeCode) {

        LocalDate today = LocalDate.now();
        LocalTime currentTime = LocalTime.now();

        AttendanceRecord record =
                attendanceRepository
                        .findByEmployeeCodeAndAttendanceDate(
                                employeeCode,
                                today)
                        .orElseThrow(() ->
                                new IllegalStateException(
                                        "No attendance record found for employee "
                                                + employeeCode
                                                + " today."
                                )
                        );

        if (record.getCheckOutTime() != null) {

            throw new IllegalStateException(
                    "Employee has already checked out today."
            );
        }

        if (record.getCheckInTime() == null) {

            throw new IllegalStateException(
                    "Employee has not checked in today."
            );
        }

        record.setCheckOutTime(currentTime);

        /*
         * Calculate overtime based on the shift.
         */
        double overtime = calculateOvertime(
                record.getCheckInTime(),
                currentTime,
                record.getShift()
        );

        record.setOvertime(overtime);

        record.setStatus(AttendanceStatus.COMPLETED);

        return attendanceRepository.save(record);
    }

    // =========================================================
    // TODAY
    // =========================================================

    @Transactional(readOnly = true)
    public List<AttendanceRecord> getTodayRecords(String firmCode) {

        if (firmCode == null || firmCode.isBlank()) {
            return attendanceRepository
                    .findByAttendanceDateOrderByCheckInTimeAsc(LocalDate.now());
        }

        return attendanceRepository
                .findByAttendanceDateAndFirmCodeOrderByCheckInTimeAsc(
                        LocalDate.now(), firmCode);
    }

    // =========================================================
    // SUMMARY
    // =========================================================

    @Transactional(readOnly = true)
    public AttendanceSummary getSummary(String firmCode) {

    	List<AttendanceRecord> records = getTodayRecords(firmCode);
        

        long present = records.stream()
                .filter(record ->
                        record.getStatus() == AttendanceStatus.PRESENT
                                || record.getStatus() == AttendanceStatus.LATE
                                || record.getStatus() == AttendanceStatus.COMPLETED)
                .count();

        long completed = records.stream()
                .filter(record ->
                        record.getStatus() == AttendanceStatus.COMPLETED)
                .count();

        long pending = records.stream()
                .filter(record ->
                        record.getStatus() == AttendanceStatus.PENDING)
                .count();

        long late = records.stream()
                .filter(record ->
                        record.getStatus() == AttendanceStatus.LATE)
                .count();

        long absent = records.stream()
                .filter(record ->
                        record.getStatus() == AttendanceStatus.ABSENT)
                .count();

        return new AttendanceSummary(
                records.size(),
                present,
                completed,
                pending,
                late,
                absent
        );
    }

    // =========================================================
    // DEPARTMENT + TEAM
    // =========================================================

    @Transactional(readOnly = true)
    public List<AttendanceRecord> getByDepartmentAndTeam(
            String department,
            String team) {

        return attendanceRepository
                .findByAttendanceDateAndDepartmentAndTeamOrderByEmployeeNameAsc(
                        LocalDate.now(),
                        department,
                        team
                );
    }

    // =========================================================
    // DATE
    // =========================================================

    @Transactional(readOnly = true)
    public List<AttendanceRecord> getByDate(LocalDate date, String firmCode) {
        if (firmCode == null || firmCode.isBlank()) {
            return attendanceRepository.findByAttendanceDateOrderByCheckInTimeAsc(date);
        }
        return attendanceRepository.findByAttendanceDateAndFirmCodeOrderByEmployeeNameAsc(date, firmCode);
    }

    // =========================================================
    // DATE RANGE
    // =========================================================

    @Transactional(readOnly = true)
    public List<AttendanceRecord> getByDateRange(LocalDate from, LocalDate to, String firmCode) {
        if (from.isAfter(to)) {
            throw new IllegalArgumentException("From date cannot be after To date.");
        }
        if (firmCode == null || firmCode.isBlank()) {
            return attendanceRepository
                    .findByAttendanceDateBetweenOrderByAttendanceDateAscCheckInTimeAsc(from, to);
        }
        return attendanceRepository
                .findByAttendanceDateBetweenAndFirmCodeOrderByAttendanceDateAscCheckInTimeAsc(from, to, firmCode);
    }

    // =========================================================
    // MANUAL ATTENDANCE
    // =========================================================

    public AttendanceRecord saveManualAttendance(
            AttendanceManualRequest request) {

        AttendanceRecord record =
                attendanceRepository
                        .findByEmployeeCodeAndAttendanceDate(
                                request.getEmployeeCode(),
                                request.getAttendanceDate()
                        )
                        .orElseGet(AttendanceRecord::new);
        
        record.setFirmCode(request.getFirmCode());
        record.setEmployeeCode(request.getEmployeeCode());
        record.setEmployeeName(request.getEmployeeName());
        record.setDepartment(request.getDepartment());
        record.setTeam(request.getTeam());
        record.setShift(request.getShift());

        record.setAttendanceDate(
                request.getAttendanceDate()
        );

        record.setCheckInTime(
                request.getCheckInTime()
        );

        record.setCheckOutTime(
                request.getCheckOutTime()
        );

        record.setRecordedBy(
                request.getRecordedBy()
        );

        record.setNotes(
                request.getNotes()
        );

        /*
         * Save GPS coordinates if provided.
         */
        if (request.getLatitude() != null) {
            record.setCheckInLatitude(
                    request.getLatitude()
            );
        }

        if (request.getLongitude() != null) {
            record.setCheckInLongitude(
                    request.getLongitude()
            );
        }

        /*
         * Determine status.
         */
        if (request.getStatus() != null) {

        	record.setStatus(
        	        AttendanceStatus.valueOf(
        	                request.getStatus().trim().toUpperCase()
        	        )
        	);

        } else if (request.getCheckOutTime() != null) {

            record.setStatus(
                    AttendanceStatus.COMPLETED
            );

        } else if (request.getCheckInTime() != null) {

            record.setStatus(
                    determineStatus(request.getCheckInTime())
            );

        } else {

            record.setStatus(
                    AttendanceStatus.PENDING
            );
        }

        /*
         * Calculate overtime automatically when both
         * check-in and check-out times are available.
         */
        if (request.getCheckInTime() != null
                && request.getCheckOutTime() != null) {

            record.setOvertime(
                    calculateOvertime(
                            request.getCheckInTime(),
                            request.getCheckOutTime(),
                            request.getShift()
                    )
            );

        } else if (request.getOvertime() != null) {

            record.setOvertime(
                    request.getOvertime()
            );

        } else {

            record.setOvertime(0.0);
        }

        return attendanceRepository.save(record);
    }

    // =========================================================
    // SHIFTS
    // =========================================================

    public List<ShiftDto> getShifts() {
        return Arrays.stream(ShiftType.values())
                .map(shift -> new ShiftDto(
                        shift.name(),
                        shift.getLabel(),
                        shift.getHours(),
                        shift.getStartTime(),
                        shift.getEndTime()
                ))
                .toList();
    }

    // =========================================================
    // STATUS
    // =========================================================

    private AttendanceStatus determineStatus(
            LocalTime checkInTime) {

        if (checkInTime.isAfter(GENERAL_SHIFT_START)) {

            return AttendanceStatus.LATE;
        }

        return AttendanceStatus.PRESENT;
    }

    // =========================================================
    // OVERTIME
    // =========================================================

    private double calculateOvertime(
            LocalTime checkIn,
            LocalTime checkOut,
            String shift) {

        if (checkIn == null || checkOut == null) {
            return 0.0;
        }

        long workedMinutes =
                Duration.between(
                        checkIn,
                        checkOut
                ).toMinutes();

        /*
         * Handle overnight shift.
         */
        if (workedMinutes < 0) {

            workedMinutes += 24 * 60;
        }

        long standardMinutes;

        if (shift == null) {

            standardMinutes = 8 * 60;

        } else {

            String normalizedShift =
                    shift.trim().toUpperCase();

            if (normalizedShift.contains("12")) {

                standardMinutes = 12 * 60;

            } else if (normalizedShift.contains("8")) {

                standardMinutes = 8 * 60;

            } else if (normalizedShift.equals("TWELVE_HOURS")) {

                standardMinutes = 12 * 60;

            } else if (normalizedShift.equals("EIGHT_HOURS")) {

                standardMinutes = 8 * 60;

            } else {

                /*
                 * GENERAL shift currently does not
                 * generate overtime.
                 */
                return 0.0;
            }
        }

        long overtimeMinutes =
                Math.max(
                        0,
                        workedMinutes - standardMinutes
                );

        return overtimeMinutes / 60.0;
    }

    // =========================================================
    // LOCATION VALIDATION
    // =========================================================

    private void validateLocation(
            Double latitude,
            Double longitude) {

        if (latitude == null || longitude == null) {

            throw new IllegalArgumentException(
                    "Location is required for attendance."
            );
        }

        double distance =
                calculateDistance(
                        latitude,
                        longitude,
                        COMPANY_LATITUDE,
                        COMPANY_LONGITUDE
                );

        if (distance > ALLOWED_RADIUS_METERS) {

            throw new IllegalArgumentException(
                    String.format(
                            "You are outside the allowed attendance location. "
                                    + "Distance: %.2f meters. "
                                    + "Allowed: %.0f meters.",
                            distance,
                            ALLOWED_RADIUS_METERS
                    )
            );
        }
    }

    // =========================================================
    // HAVERSINE DISTANCE
    // =========================================================

    private double calculateDistance(
            double lat1,
            double lon1,
            double lat2,
            double lon2) {

        final double EARTH_RADIUS_METERS =
                6371000.0;

        double latDistance =
                Math.toRadians(lat2 - lat1);

        double lonDistance =
                Math.toRadians(lon2 - lon1);

        double a =
                Math.sin(latDistance / 2)
                        * Math.sin(latDistance / 2)
                        + Math.cos(Math.toRadians(lat1))
                        * Math.cos(Math.toRadians(lat2))
                        * Math.sin(lonDistance / 2)
                        * Math.sin(lonDistance / 2);

        double c =
                2 * Math.atan2(
                        Math.sqrt(a),
                        Math.sqrt(1 - a)
                );

        return EARTH_RADIUS_METERS * c;
    }

    // =========================================================
    // SUMMARY DTO
    // =========================================================

    public record AttendanceSummary(
            long total,
            long present,
            long completed,
            long pending,
            long late,
            long absent
    ) {
    }
}