package com.mardabang.hrms.attendance.entity;

public enum AttendanceStatus {
    PENDING,
    PRESENT,
    LATE,
    COMPLETED,
    ABSENT,
    PAID_LEAVE,
    WEEKLY_OFF,
    HOLIDAY
}
