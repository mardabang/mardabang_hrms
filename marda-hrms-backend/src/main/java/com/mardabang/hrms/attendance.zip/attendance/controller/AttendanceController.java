package com.mardabang.hrms.attendance.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.mardabang.hrms.attendance.dto.AttendanceManualRequest;
import com.mardabang.hrms.attendance.dto.AttendancePunchRequest;
import com.mardabang.hrms.attendance.dto.ShiftDto;
import com.mardabang.hrms.attendance.entity.AttendanceRecord;
import com.mardabang.hrms.attendance.service.AttendanceService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/attendance")
@CrossOrigin(origins = "*")
public class AttendanceController {

    private final AttendanceService attendanceService;
    

    public AttendanceController(AttendanceService attendanceService) {
        this.attendanceService = attendanceService;
    }

    // ---------------------------------------------------------
    // CHECK IN
    // ---------------------------------------------------------

    @PostMapping("/checkin")
    public ResponseEntity<?> checkIn(
            @Valid @RequestBody AttendancePunchRequest request) {

        try {

            System.out.println("========================================");
            System.out.println("ATTENDANCE CHECK-IN REQUEST");
            System.out.println("Employee Code : " + request.getEmployeeCode());
            System.out.println("Employee Name : " + request.getEmployeeName());
            System.out.println("Department    : " + request.getDepartment());
            System.out.println("Team          : " + request.getTeam());
            System.out.println("Shift         : " + request.getShift());
            System.out.println("Recorded By   : " + request.getRecordedBy());
            System.out.println("Latitude      : " + request.getLatitude());
            System.out.println("Longitude     : " + request.getLongitude());
            System.out.println("========================================");

            AttendanceRecord record =
                    attendanceService.checkIn(request);

            return ResponseEntity.ok(record);

        } catch (IllegalArgumentException e) {

            System.err.println("CHECK-IN VALIDATION ERROR:");
            e.printStackTrace();

            return ResponseEntity
                    .badRequest()
                    .body(new ErrorResponse(e.getMessage()));

        } catch (IllegalStateException e) {

            System.err.println("CHECK-IN STATE ERROR:");
            e.printStackTrace();

            return ResponseEntity
                    .status(HttpStatus.CONFLICT)
                    .body(new ErrorResponse(e.getMessage()));

        } catch (Exception e) {

            System.err.println("CHECK-IN INTERNAL ERROR:");
            e.printStackTrace();

            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ErrorResponse(
                            e.getMessage() != null
                                    ? e.getMessage()
                                    : "Internal server error while marking attendance."
                    ));
        }
    }

    // ---------------------------------------------------------
    // CHECK OUT
    // ---------------------------------------------------------

    @PostMapping("/checkout/{employeeCode}")
    public ResponseEntity<?> checkOut(
            @PathVariable String employeeCode) {

        try {

            AttendanceRecord record =
                    attendanceService.checkOut(employeeCode);

            return ResponseEntity.ok(record);

        } catch (IllegalArgumentException e) {

            return ResponseEntity
                    .badRequest()
                    .body(new ErrorResponse(e.getMessage()));

        } catch (IllegalStateException e) {

            return ResponseEntity
                    .status(HttpStatus.CONFLICT)
                    .body(new ErrorResponse(e.getMessage()));

        } catch (Exception e) {

            e.printStackTrace();

            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ErrorResponse(
                            e.getMessage() != null
                                    ? e.getMessage()
                                    : "Internal server error while checking out."
                    ));
        }
    }

    // ---------------------------------------------------------
    // TODAY'S ATTENDANCE
    // ---------------------------------------------------------

    @GetMapping("/today")
    public ResponseEntity<List<AttendanceRecord>> getTodayRecords(
            @RequestParam(required = false) String firmCode) {

        return ResponseEntity.ok(
                attendanceService.getTodayRecords(firmCode)
        );
    }

    // ---------------------------------------------------------
    // SUMMARY
    // ---------------------------------------------------------

    @GetMapping("/summary")
    public ResponseEntity<AttendanceService.AttendanceSummary> getSummary(
            @RequestParam(required = false) String firmCode) {

        return ResponseEntity.ok(
                attendanceService.getSummary(firmCode)
        );
    }

    // ---------------------------------------------------------
    // DEPARTMENT + TEAM
    // ---------------------------------------------------------

    @GetMapping("/department")
    public ResponseEntity<List<AttendanceRecord>> getByDepartmentAndTeam(
            @RequestParam String department,
            @RequestParam String team) {

        return ResponseEntity.ok(
                attendanceService.getByDepartmentAndTeam(
                        department,
                        team
                )
        );
    }

    // ---------------------------------------------------------
    // ATTENDANCE BY DATE
    // ---------------------------------------------------------

    @GetMapping("/date")
    public ResponseEntity<List<AttendanceRecord>> getByDate(
            @RequestParam LocalDate date,
            @RequestParam(required = false) String firmCode) {
        return ResponseEntity.ok(attendanceService.getByDate(date, firmCode));
    }

    // ---------------------------------------------------------
    // ATTENDANCE BY DATE RANGE
    // ---------------------------------------------------------

    @GetMapping("/range")
    public ResponseEntity<List<AttendanceRecord>> getByDateRange(
            @RequestParam LocalDate from,
            @RequestParam LocalDate to,
            @RequestParam(required = false) String firmCode) {
        return ResponseEntity.ok(attendanceService.getByDateRange(from, to, firmCode));
    }

    // ---------------------------------------------------------
    // MANUAL ATTENDANCE
    // ---------------------------------------------------------

    @PostMapping("/manual")
    public ResponseEntity<?> saveManualAttendance(
            @Valid @RequestBody AttendanceManualRequest request) {

        try {

            AttendanceRecord record =
                    attendanceService.saveManualAttendance(request);

            return ResponseEntity.ok(record);

        } catch (IllegalArgumentException e) {

            return ResponseEntity
                    .badRequest()
                    .body(new ErrorResponse(e.getMessage()));

        } catch (IllegalStateException e) {

            return ResponseEntity
                    .status(HttpStatus.CONFLICT)
                    .body(new ErrorResponse(e.getMessage()));

        } catch (Exception e) {

            e.printStackTrace();

            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ErrorResponse(
                            e.getMessage() != null
                                    ? e.getMessage()
                                    : "Internal server error."
                    ));
        }
    }

    // ---------------------------------------------------------
    // SHIFTS
    // ---------------------------------------------------------

    @GetMapping("/shifts")
    public ResponseEntity<List<ShiftDto>> getShifts() {
        return ResponseEntity.ok(
                attendanceService.getShifts()
        );
    }

    // ---------------------------------------------------------
    // ERROR RESPONSE
    // ---------------------------------------------------------

    public record ErrorResponse(String message) {
    }
}