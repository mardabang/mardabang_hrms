package com.mardabang.hrms.attendance.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mardabang.hrms.attendance.entity.AttendanceRecord;

public interface AttendanceRepository extends JpaRepository<AttendanceRecord, Long> {

    List<AttendanceRecord> findByAttendanceDateOrderByCheckInTimeAsc(
            LocalDate attendanceDate);

    List<AttendanceRecord> findByAttendanceDateBetweenOrderByAttendanceDateAscCheckInTimeAsc(
            LocalDate from,
            LocalDate to);

    List<AttendanceRecord> findByAttendanceDateAndDepartmentAndTeamOrderByEmployeeNameAsc(
            LocalDate attendanceDate,
            String department,
            String team);

    Optional<AttendanceRecord> findByEmployeeCodeAndAttendanceDate(
            String employeeCode,
            LocalDate attendanceDate);
    
    List<AttendanceRecord>
    findByEmployeeCodeAndAttendanceDateBetweenOrderByAttendanceDateAsc(
            String employeeCode,
            LocalDate from,
            LocalDate to);
    
    List<AttendanceRecord> findByAttendanceDateAndFirmCodeOrderByCheckInTimeAsc(
            LocalDate attendanceDate,
            String firmCode);
    
    List<AttendanceRecord> findByAttendanceDateBetweenAndFirmCodeOrderByAttendanceDateAscCheckInTimeAsc(
            LocalDate from, LocalDate to, String firmCode);
    
    List<AttendanceRecord> findByAttendanceDateAndFirmCodeOrderByEmployeeNameAsc(
            LocalDate attendanceDate, String firmCode);
    
    List<AttendanceRecord> findByEmployeeCode(String employeeCode);
    
    
}