package com.mardabang.hrms.attendance.dto;

import java.time.LocalDate;
import java.time.LocalTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AttendanceManualRequest {

	private String firmCode;

    private String employeeCode;

    private String employeeName;

    private String department;

    private String team;

    private String shift;

    private LocalDate attendanceDate;

    private LocalTime checkInTime;

    private LocalTime checkOutTime;

    private Double overtime;

    private String status;

    private String recordedBy;

    private String notes;

    private Double latitude;

    private Double longitude;
}