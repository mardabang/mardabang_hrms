package com.mardabang.hrms.auth.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import com.mardabang.hrms.auth.dto.LoginRequest;
import com.mardabang.hrms.auth.dto.LoginResponse;
import com.mardabang.hrms.auth.dto.RegisterRequest;
import com.mardabang.hrms.auth.security.JwtUtil;
import com.mardabang.hrms.employee.service.EmployeeService;
import com.mardabang.hrms.firms.entity.Firm;
import com.mardabang.hrms.user.entity.Role;
import com.mardabang.hrms.user.entity.User;
import com.mardabang.hrms.user.service.UserService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UserService userService;
    private final JwtUtil jwtUtil;
    private final PasswordEncoder passwordEncoder;
    private final EmployeeService employeeService;

    public AuthController(UserService userService,
                          JwtUtil jwtUtil,
                          PasswordEncoder passwordEncoder,
                          EmployeeService employeeService) {
        this.userService = userService;
        this.jwtUtil = jwtUtil;
        this.passwordEncoder = passwordEncoder;
        this.employeeService = employeeService;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody RegisterRequest request) {

        if (userService.emailExists(request.getEmail())) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("Email already exists.");
        }
        if (request.getMobile() != null && !request.getMobile().isBlank()
                && userService.mobileExists(request.getMobile())) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("Mobile number already exists.");
        }

        Role role = request.getRole();
        String employeeCode = request.getEmployeeCode() == null
                ? null : request.getEmployeeCode().trim();
        if (role == Role.INPUTER) {
            if (employeeCode == null || employeeCode.isBlank()) {
                return ResponseEntity.badRequest().body("Employee code is required for an Inputer account.");
            }
            if (employeeService.getEmployeeByCode(employeeCode) == null) {
                return ResponseEntity.badRequest().body("Employee code does not exist.");
            }
            if (userService.employeeCodeExists(employeeCode)) {
                return ResponseEntity.status(HttpStatus.CONFLICT)
                        .body("An account is already linked to this employee code.");
            }
        } else {
            employeeCode = null;
        }

        User user = User.builder()
                .fullName(request.getFullName())
                .email(request.getEmail())
                .mobile(request.getMobile())
                .employeeCode(employeeCode)
                .password(request.getPassword())
                .role(role)
                .active(true)
                .build();

        userService.saveUser(user);

        return ResponseEntity.status(HttpStatus.CREATED)
                .body("User registered successfully.");
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequest request) {

        User user = userService.getUserByEmail(request.getEmail())
                .orElse(null);

        if (user == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Invalid email or password.");
        }

        if (!Boolean.TRUE.equals(user.getActive())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Invalid email or password.");
        }

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Invalid email or password.");
        }

        String token = jwtUtil.generateToken(
                user.getEmail(),
                user.getRole().name()
        );

        List<String> firmCodes = user.getFirms().stream()
                .map(Firm::getCode)
                .toList();

        return ResponseEntity.ok(
                new LoginResponse(
                        token,
                        user.getId(),
                        user.getEmail(),
                        user.getFullName(),
                        user.getRole().name(),
                        user.getEmployeeCode(),
                        firmCodes
                )
        );
    }
}
