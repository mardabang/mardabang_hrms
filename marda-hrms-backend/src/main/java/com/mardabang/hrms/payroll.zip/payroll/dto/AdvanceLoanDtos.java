package com.mardabang.hrms.payroll.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public class AdvanceLoanDtos {

    public static class IssueRequest {
        private String employeeCode;
        private String type; // ADVANCE or LOAN
        private BigDecimal amount;
        private LocalDate issueDate;
        private String reason;

        public String getEmployeeCode() { return employeeCode; }
        public void setEmployeeCode(String employeeCode) { this.employeeCode = employeeCode; }
        public String getType() { return type; }
        public void setType(String type) { this.type = type; }
        public BigDecimal getAmount() { return amount; }
        public void setAmount(BigDecimal amount) { this.amount = amount; }
        public LocalDate getIssueDate() { return issueDate; }
        public void setIssueDate(LocalDate issueDate) { this.issueDate = issueDate; }
        public String getReason() { return reason; }
        public void setReason(String reason) { this.reason = reason; }
    }

    public static class RepayRequest {
        private BigDecimal amount;
        private LocalDate repaymentDate;
        private String notes;

        public BigDecimal getAmount() { return amount; }
        public void setAmount(BigDecimal amount) { this.amount = amount; }
        public LocalDate getRepaymentDate() { return repaymentDate; }
        public void setRepaymentDate(LocalDate repaymentDate) { this.repaymentDate = repaymentDate; }
        public String getNotes() { return notes; }
        public void setNotes(String notes) { this.notes = notes; }
    }

    public static class SummaryResponse {
        private BigDecimal advance;
        private BigDecimal loan;
        private BigDecimal outstanding;

        public SummaryResponse(BigDecimal advance, BigDecimal loan, BigDecimal outstanding) {
            this.advance = advance;
            this.loan = loan;
            this.outstanding = outstanding;
        }
        public BigDecimal getAdvance() { return advance; }
        public BigDecimal getLoan() { return loan; }
        public BigDecimal getOutstanding() { return outstanding; }
    }

    // A single ledger-style row — either an "issue" (debit-style: money given to employee)
    // or a "repayment" (credit-style: employee paying it back)
    public static class LedgerTransaction {
        private String id;
        private LocalDate date;
        private String type;        // "Advance", "Loan", "Advance Repayment", "Loan Repayment"
        private String description;
        private BigDecimal credit;  // repayments
        private BigDecimal debit;   // issued amounts

        public LedgerTransaction(String id, LocalDate date, String type, String description,
                                  BigDecimal credit, BigDecimal debit) {
            this.id = id;
            this.date = date;
            this.type = type;
            this.description = description;
            this.credit = credit;
            this.debit = debit;
        }
        public String getId() { return id; }
        public LocalDate getDate() { return date; }
        public String getType() { return type; }
        public String getDescription() { return description; }
        public BigDecimal getCredit() { return credit; }
        public BigDecimal getDebit() { return debit; }
    }
}