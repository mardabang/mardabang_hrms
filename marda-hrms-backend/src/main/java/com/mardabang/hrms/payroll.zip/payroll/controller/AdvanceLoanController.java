package com.mardabang.hrms.payroll.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mardabang.hrms.payroll.dto.AdvanceLoanDtos.IssueRequest;
import com.mardabang.hrms.payroll.dto.AdvanceLoanDtos.LedgerTransaction;
import com.mardabang.hrms.payroll.dto.AdvanceLoanDtos.RepayRequest;
import com.mardabang.hrms.payroll.dto.AdvanceLoanDtos.SummaryResponse;
import com.mardabang.hrms.payroll.entity.AdvanceLoanRecord;
import com.mardabang.hrms.payroll.service.AdvanceLoanService;

@RestController
@RequestMapping("/api/payroll/advances")
public class AdvanceLoanController {

    private final AdvanceLoanService advanceLoanService;

    public AdvanceLoanController(AdvanceLoanService advanceLoanService) {
        this.advanceLoanService = advanceLoanService;
    }

    @PostMapping("/issue")
    public ResponseEntity<?> issue(@RequestBody IssueRequest request) {
        try {
            AdvanceLoanRecord record = advanceLoanService.issue(request);
            return ResponseEntity.ok(record);
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(Map.of("message", ex.getMessage()));
        }
    }

    @PostMapping("/{recordId}/repay")
    public ResponseEntity<?> repay(@PathVariable Long recordId, @RequestBody RepayRequest request) {
        try {
            AdvanceLoanRecord record = advanceLoanService.recordRepayment(recordId, request);
            return ResponseEntity.ok(record);
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(Map.of("message", ex.getMessage()));
        }
    }

    @GetMapping
    public ResponseEntity<?> getRecords(@RequestParam String employeeCode) {
        try {
            List<AdvanceLoanRecord> records = advanceLoanService.getRecordsForEmployee(employeeCode);
            return ResponseEntity.ok(records);
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(Map.of("message", ex.getMessage()));
        }
    }

    @GetMapping("/summary")
    public ResponseEntity<?> getSummary(@RequestParam String employeeCode) {
        try {
            SummaryResponse summary = advanceLoanService.getSummary(employeeCode);
            return ResponseEntity.ok(summary);
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(Map.of("message", ex.getMessage()));
        }
    }

    @GetMapping("/transactions")
    public ResponseEntity<?> getTransactions(@RequestParam String employeeCode) {
        try {
            List<LedgerTransaction> transactions = advanceLoanService.getLedgerTransactions(employeeCode);
            return ResponseEntity.ok(transactions);
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(Map.of("message", ex.getMessage()));
        }
    }
}