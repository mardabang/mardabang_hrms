package com.mardabang.hrms.payroll.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.mardabang.hrms.payroll.entity.AdvanceLoanRecord;

public interface AdvanceLoanRecordRepository extends JpaRepository<AdvanceLoanRecord, Long> {
    List<AdvanceLoanRecord> findByEmployeeIdOrderByIssueDateAsc(Long employeeId);
}