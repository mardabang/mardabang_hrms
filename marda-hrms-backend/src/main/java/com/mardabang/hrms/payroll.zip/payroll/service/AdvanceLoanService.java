package com.mardabang.hrms.payroll.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mardabang.hrms.employee.entity.Employee;
import com.mardabang.hrms.employee.repository.EmployeeRepository;
import com.mardabang.hrms.payroll.dto.AdvanceLoanDtos.*;
import com.mardabang.hrms.payroll.entity.AdvanceLoanRecord;
import com.mardabang.hrms.payroll.entity.AdvanceLoanRepayment;
import com.mardabang.hrms.payroll.repository.AdvanceLoanRecordRepository;
import com.mardabang.hrms.payroll.repository.AdvanceLoanRepaymentRepository;

@Service
public class AdvanceLoanService {

    private final AdvanceLoanRecordRepository recordRepository;
    private final AdvanceLoanRepaymentRepository repaymentRepository;
    private final EmployeeRepository employeeRepository;

    public AdvanceLoanService(AdvanceLoanRecordRepository recordRepository,
                               AdvanceLoanRepaymentRepository repaymentRepository,
                               EmployeeRepository employeeRepository) {
        this.recordRepository = recordRepository;
        this.repaymentRepository = repaymentRepository;
        this.employeeRepository = employeeRepository;
    }

    private Employee resolveEmployee(String employeeCode) {
        if (employeeCode == null || employeeCode.isBlank()) {
            throw new IllegalArgumentException("Employee code is required.");
        }
        return employeeRepository.findByEmployeeCode(employeeCode.trim())
            .orElseThrow(() -> new IllegalArgumentException("Employee not found."));
    }

    @Transactional
    public AdvanceLoanRecord issue(IssueRequest request) {
        Employee employee = resolveEmployee(request.getEmployeeCode());

        String type = request.getType() == null ? "" : request.getType().trim().toUpperCase();
        if (!type.equals("ADVANCE") && !type.equals("LOAN")) {
            throw new IllegalArgumentException("Type must be ADVANCE or LOAN.");
        }
        if (request.getAmount() == null || request.getAmount().signum() <= 0) {
            throw new IllegalArgumentException("Amount must be greater than zero.");
        }
        if (request.getIssueDate() == null) {
            throw new IllegalArgumentException("Issue date is required.");
        }

        BigDecimal amount = request.getAmount().setScale(2, RoundingMode.HALF_UP);

        AdvanceLoanRecord record = AdvanceLoanRecord.builder()
            .employeeId(employee.getId())
            .type(type)
            .principalAmount(amount)
            .outstandingAmount(amount)
            .issueDate(request.getIssueDate())
            .reason(request.getReason())
            .status("ACTIVE")
            .build();

        return recordRepository.save(record);
    }

    @Transactional
    public AdvanceLoanRecord recordRepayment(Long recordId, RepayRequest request) {
        if (recordId == null) {
            throw new IllegalArgumentException("Record ID is required.");
        }
        if (request.getAmount() == null || request.getAmount().signum() <= 0) {
            throw new IllegalArgumentException("Repayment amount must be greater than zero.");
        }
        if (request.getRepaymentDate() == null) {
            throw new IllegalArgumentException("Repayment date is required.");
        }

        AdvanceLoanRecord record = recordRepository.findById(recordId)
            .orElseThrow(() -> new IllegalArgumentException("Advance/loan record not found."));

        if ("CLOSED".equalsIgnoreCase(record.getStatus())) {
            throw new IllegalArgumentException("This advance/loan is already fully repaid.");
        }

        BigDecimal amount = request.getAmount().setScale(2, RoundingMode.HALF_UP);
        if (amount.compareTo(record.getOutstandingAmount()) > 0) {
            throw new IllegalArgumentException(
                "Repayment amount exceeds outstanding balance of " + record.getOutstandingAmount());
        }

        AdvanceLoanRepayment repayment = AdvanceLoanRepayment.builder()
            .advanceLoanRecordId(record.getId())
            .amount(amount)
            .repaymentDate(request.getRepaymentDate())
            .notes(request.getNotes())
            .build();
        repaymentRepository.save(repayment);

        BigDecimal newOutstanding = record.getOutstandingAmount().subtract(amount)
            .setScale(2, RoundingMode.HALF_UP);
        record.setOutstandingAmount(newOutstanding);
        if (newOutstanding.signum() <= 0) {
            record.setStatus("CLOSED");
        }

        return recordRepository.save(record);
    }

    public List<AdvanceLoanRecord> getRecordsForEmployee(String employeeCode) {
        Employee employee = resolveEmployee(employeeCode);
        return recordRepository.findByEmployeeIdOrderByIssueDateAsc(employee.getId());
    }

    public SummaryResponse getSummary(String employeeCode) {
        List<AdvanceLoanRecord> records = getRecordsForEmployee(employeeCode);

        BigDecimal advance = records.stream()
            .filter(r -> "ADVANCE".equalsIgnoreCase(r.getType()) && "ACTIVE".equalsIgnoreCase(r.getStatus()))
            .map(AdvanceLoanRecord::getOutstandingAmount)
            .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal loan = records.stream()
            .filter(r -> "LOAN".equalsIgnoreCase(r.getType()) && "ACTIVE".equalsIgnoreCase(r.getStatus()))
            .map(AdvanceLoanRecord::getOutstandingAmount)
            .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal outstanding = advance.add(loan);

        return new SummaryResponse(advance, loan, outstanding);
    }

    public List<LedgerTransaction> getLedgerTransactions(String employeeCode) {
        List<AdvanceLoanRecord> records = getRecordsForEmployee(employeeCode);
        if (records.isEmpty()) {
            return List.of();
        }

        List<Long> recordIds = records.stream().map(AdvanceLoanRecord::getId).collect(Collectors.toList());
        List<AdvanceLoanRepayment> repayments = repaymentRepository.findByAdvanceLoanRecordIdIn(recordIds);

        List<LedgerTransaction> transactions = new ArrayList<>();

        for (AdvanceLoanRecord record : records) {
            String label = "ADVANCE".equalsIgnoreCase(record.getType()) ? "Advance" : "Loan";
            transactions.add(new LedgerTransaction(
                "issue-" + record.getId(),
                record.getIssueDate(),
                label,
                (record.getReason() == null || record.getReason().isBlank())
                    ? label + " issued" : record.getReason(),
                BigDecimal.ZERO,
                record.getPrincipalAmount()
            ));
        }

        for (AdvanceLoanRepayment repayment : repayments) {
            AdvanceLoanRecord parent = records.stream()
                .filter(r -> r.getId().equals(repayment.getAdvanceLoanRecordId()))
                .findFirst().orElse(null);
            String label = parent != null && "ADVANCE".equalsIgnoreCase(parent.getType())
                ? "Advance Repayment" : "Loan Repayment";

            transactions.add(new LedgerTransaction(
                "repay-" + repayment.getId(),
                repayment.getRepaymentDate(),
                label,
                (repayment.getNotes() == null || repayment.getNotes().isBlank())
                    ? "Repayment" : repayment.getNotes(),
                repayment.getAmount(),
                BigDecimal.ZERO
            ));
        }

        transactions.sort((a, b) -> a.getDate().compareTo(b.getDate()));
        return transactions;
    }
}