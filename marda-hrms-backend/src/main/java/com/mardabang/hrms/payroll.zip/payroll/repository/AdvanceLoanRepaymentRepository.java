package com.mardabang.hrms.payroll.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.mardabang.hrms.payroll.entity.AdvanceLoanRepayment;

public interface AdvanceLoanRepaymentRepository extends JpaRepository<AdvanceLoanRepayment, Long> {
    List<AdvanceLoanRepayment> findByAdvanceLoanRecordIdOrderByRepaymentDateAsc(Long advanceLoanRecordId);
    List<AdvanceLoanRepayment> findByAdvanceLoanRecordIdIn(List<Long> recordIds);
}